const libros = require('./libros');
module.exports = {
libros: libros
};